<?php
class DB{

    private static $host = 'localhost';
    private static $user = 'root';
    private static $pwd = '';
    private static $db  = 'data';
    public static $conn;
    private static $data = array();

   

   public static function table($tab, $arr = []){
       $key = array_keys($arr);
       $val = array_values($arr);
       if(!empty($arr)){
          
        $conn =  new mysqli(self::$host, self::$user, self::$pwd, self::$db);
        $sql =$conn->query("SELECT * FROM $tab WHERE $key[0] = $val[0] ");
        $res = $sql->fetch_object();
        $query = array();
        while($row = $sql->fetch_object()){
            $query[] =$row;
        }
        $arr = array(
            "num_rows"=>$sql->num_rows,
            "row"=>$res,
            "result"=>$query
        );
        return json_decode(json_encode($arr));

       } else {
           
        $conn =  new mysqli(self::$host, self::$user, self::$pwd, self::$db);
        $sql =$conn->query("SELECT * FROM $tab");
        $query = array();
        while($row = $sql->fetch_object()){
            $query[] =$row;
        }
        $arr = array(
            "num_rows"=>$sql->num_rows,
            "result"=>$query
        );
        return json_decode(json_encode($arr));

       }
      
    }

}

