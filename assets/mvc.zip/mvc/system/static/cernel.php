<?php
class system{
    
    public static function view($view, $data = []){
        try{
            require_once"application/views/".$view.".php";
        } catch(Exception $e){
            echo $e->getMessage();
        }
    }

}