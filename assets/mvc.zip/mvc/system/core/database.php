<?php
class Database{
    /*This is configuration for connect to database
     *Before using this framewok we hop you read for this docUmentations
    */
    //varaiable host for host database mysql
    private $host = 'localhost';
    private $user = 'root';
    private $pwd = '';
    private $db  = 'data';
    private $conn;
    private $data = array();
    function __construct(){
        
        $this->conn = new mysqli($this->host, $this->user, $this->pwd, $this->db);
        
    }

    function get($tab){
        $sql = $this->conn->query("SELECT * FROM $tab");
        $query = array();
        while($row = $sql->fetch_object()){
            $query[] =$row;
        }
        $arr = array(
            "num_rows"=>$sql->num_rows,
            "result"=>$query
        );
        return json_decode(json_encode($arr));
    }
    
}