<?php
// require_once'database.php';
 class Model{
     protected $db;
     function __construct(){
         $this->db = new Database();
     }
 }