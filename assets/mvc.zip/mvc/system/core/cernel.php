<?php
class cernel{

    function view($view, $data = []){
        try{
            require_once"application/views/".$view.".php";
        } catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function model($model, $name){
        if(file_exists('application/models/'.$model.'.php')){
            require_once'application/models/'.$model.'.php';
            if(class_exists($model)){
                $this->{$name} = new $model();
            } else {
                echo 'The model name must be the same with class';
            }
        } else {
            echo 'The file '.$model.' was not found';
        }
    }

}