<?php
require_once'core/App.php';
require_once'core/controller.php';
require_once'core/cernel.php'; 
require_once'core/model.php';
require_once'core/database.php';

require_once'static/db.php';
require_once'static/cernel.php';