<?php

foreach($data['sql'] as $row){
    echo $row->nama_prod;
}