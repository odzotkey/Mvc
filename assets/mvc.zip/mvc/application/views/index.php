<?php
if($data['sql']){
    foreach($data['sql']as $row){
        echo $row->nama_prod.'<br>';
    }
}

echo "<pre>";
print_r(DB::get('products')->result);