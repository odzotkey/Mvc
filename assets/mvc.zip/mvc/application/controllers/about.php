<?php
class about extends Controller{
    function index(){
        echo 'hallo index about';
    }
    function data(){
        echo 'Hallo about data';
    }
}