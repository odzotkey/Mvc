<?php
class home extends Controller{
    public function __construct(){
        parent:: __construct();
        $this->load->model('mymodel', 'models');
      
    }
    public function index(){
        $data['sql'] = $this->load->models->getData();
        $this->load->view('index',$data);
    }

    public function view(){
        $data['sql'] = DB::table('products', array("harga_prod"=>340000))->result;
        system::view('about', $data);
    }
}