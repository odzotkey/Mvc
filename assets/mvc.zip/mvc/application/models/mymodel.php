<?php

class mymodel extends Model{
    function getData(){
       $data =  $this->db->get('products');
       return $data->result;
      
    }
}

