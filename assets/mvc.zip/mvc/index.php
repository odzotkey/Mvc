<?php
require_once'system/initialize.php';
$app = new App();